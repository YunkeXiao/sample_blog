I used Firefox (Quantum) v62.0.3 to test my HTML/CSS and only put in real links in the 'Read More' links, all the
other links point the top of the page
